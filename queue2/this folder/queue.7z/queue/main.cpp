
#include "linkedlist.h"
#include "baseNode.h"
#include <iostream>
#include <string>
#include "queue2.h"
#include "queue.h"

using namespace std;

int main()
{
    string str1;
    queue<string> strq;
    cout<<"is empty should be 1: "<<strq.empty()<<endl;

    cout<<"size should be 0: "<<strq.size();
    strq.enqueue("ss:)");
    strq.enqueue("ada");
    cout<<endl<<strq<<endl;
    strq.dequeue(str1);
    cout<<"should be \"ss:)\" : "<<str1;
    cout<<"size should be 1: "<<strq.size()<<endl;
    cout<<"is empty should be 0: "<<strq.empty()<<endl;
    strq.clear();
    cout<<"size should be 0: "<<strq.size()<<endl;
    cout<<"is empty should be 1: "<<strq.empty()<<endl;




    qqueue<char> qa;
    char c = 'c';
    char b = 'b';
    char d = 'd';
    char z;
    qa.enqqueue(b);
    qa.enqqueue(d);
    qa.enqqueue(c);

    qa.deqqueue(z);
    cout<<"should be 'c': "<<c<<endl;
    qa.deqqueue(z);
    cout<<"should be 'b': "<<z<<endl;
    cout<<"is empty? "<<qa.empty();



    return 0;
}


